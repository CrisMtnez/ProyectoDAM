Stylised Box

[----_Info_----]
Hello,
I am not going to add so much Meshes in the future cause
I canceled my Maya LT subscription, however I ll ad more textures in the next update.
If you have wishes or suggestions please write them into the review section.


[-----Version 1.2.2---]
-4 new particle systems
	-Ball_1
	-Circle_1
	-Circle_1
	-Splash_1
-secret language (for puzzle games)
	-request stones with engravings

[-----Version 1.2.1---]
-Bush_12   (Bush_6Mat)
-Bush_13   (Bush_7Mat)
-Pot_1
-Pot_2
-Pot_3

[-----Version 1.2-----]
-Tree_7 (dark/ bright colore)
-Tree_8
-leaves_1
-Mushroom_2
-tiny_stone_2

[-----Version 1.1-----]
-Pillar_1
-reworked grass texture
-Mushroom_1
-Rock_Formation_1

[-----Version 1.0-----]


__________________________
Donations are totally appreciated. (Paypal: reneborger@gmx.de)
Have a nice day!